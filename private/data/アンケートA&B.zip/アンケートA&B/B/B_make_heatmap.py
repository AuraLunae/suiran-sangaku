import re
import pandas as pd
import matplotlib.pyplot as plt
import japanize_matplotlib
import seaborn as sns

sns.set_theme(style="whitegrid", context="notebook")
japanize_matplotlib.japanize()

df = pd.read_excel("B_アンケートデータ_数値化.xlsx")
df = df.drop(columns=["回答者番号"])

questions = dict(zip([f"Q{re.match(r'\s*(\d+)', c).group(1)}" for c in df.columns], df.columns))
df.columns = list(questions.keys())

corr_matrix = df.corr(method="spearman", numeric_only=True)

plt.figure(figsize=(40, 36))
ax = sns.heatmap(corr_matrix,
                 vmin=-1.0, vmax=1.0,
                 square=True, cmap="coolwarm",
                 linewidths=0.1, linecolor="white",
                 annot=False,                  # ← 数値は下で自前で書くのでFalseに変更
                 cbar_kws={"shrink": 0.5})

ax.xaxis.tick_top()
ax.xaxis.set_label_position("top")
ax.tick_params(axis="x", labelsize=10)
ax.tick_params(axis="y", labelsize=10)

# ↓ 追加：1マスずつ「ペア名（小）」と「相関係数」を書く
names = list(corr_matrix.columns)
for i, row_name in enumerate(names):
    for j, col_name in enumerate(names):
        v = corr_matrix.iloc[i, j]
        color = "white" if abs(v) >= 0.6 else "black"   # 濃いマスは白文字
        ax.text(j + 0.5, i + 0.28, f"{row_name}×{col_name}",
                ha="center", va="center", fontsize=4.5, color=color, alpha=0.8)
        ax.text(j + 0.5, i + 0.62, f"{v:.2f}",
                ha="center", va="center", fontsize=8, color=color)

plt.savefig("B_heatmap.png", dpi=150, bbox_inches="tight")
plt.savefig("B_heatmap.svg", bbox_inches="tight")
plt.show()

pd.Series(questions, name="質問文").to_csv("B_question_list.csv", encoding="utf-8-sig")