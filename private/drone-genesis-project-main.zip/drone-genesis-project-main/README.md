# ドローン自律飛行プロジェクト

## プロジェクトの現状
* 目的: 風外乱下でも安定してホバリング・目標到達できる、自律飛行ドローンの強化学習方策を作ること。
* 現在の構成: Unityは完全に廃止しました。Python完結で、Genesis World(GPU並列物理シミュレータ)+ rsl-rl-lib(PPO)
* 物理モデル: Genesisの組み込みのツールである、DroneEntity(Crazyflie 2.X / CF2Xモデル)による4プロペラのRPM直接制御(3軸の単純化された推力モデルではなく、実機に近いローレベル制御)
* 環境構築: uv(Pythonのバージョン指定も行う)
* 風: Ornstein-Uhlenbeck過程(OU過程)による時間変化する乱気流。エピソードごとに強さ・方向・乱れ方を再抽選(ドメインランダム化)
* 16384並列での学習を成功させようとしている。現在は報酬モデルを「遠さへの継続減点+生存ボーナス+目標到達ボーナス」の構成に拡張したところです。
* やりたいこと:
  * seabornで、綺麗なグラスを描きたい
  * より良い報酬モデルを考えたい
  * より、リアルに近い実装を心がけたい

## ファイル構成
```
drone-genesis-project/
├── wind_hover_env.py   # 環境定義(公式HoverEnv + OU過程の風 + 拡張報酬)
├── train.py             # 学習スクリプト(公式hover_train.pyベース)
├── eval.py               # 評価スクリプト(公式hover_eval.pyベース)
├── pyproject.toml       # uv用の依存関係定義
└── README.md
```


## ベースのコード
* [Genesis world公式 ](https://github.com/Genesis-Embodied-AI/genesis-world/blob/main/examples/drone/hover_train.py)
* [Qiita WSL2+Ubuntu 24.04でGenesis環境構築～学習までやってみた](https://qiita.com/t_tanno/items/a17f0717d136a4f96da0)
